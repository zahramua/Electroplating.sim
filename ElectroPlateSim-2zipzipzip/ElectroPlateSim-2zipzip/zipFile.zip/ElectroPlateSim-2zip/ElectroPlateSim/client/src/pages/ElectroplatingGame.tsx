import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Battery, RefreshCw, Info, FlaskConical, Microscope, Trophy, Plug } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

type ParticleType = 'ion' | 'anode_electron' | 'cathode_electron';
type ElectronSegment = 'anode_wire' | 'cathode_wire';

interface Particle {
  id: string;
  type: ParticleType;
  x: number;
  y: number;
  status: 'active' | 'waiting' | 'plated';
  segment?: ElectronSegment;
  progress?: number;
}

const ANODE_START_MASS = 50;
const CATHODE_START_MASS = 25;
const MASS_PER_UNIT = 5;
const TOTAL_PLATING_GOAL = 6;

const COPPER_COLOR = { r: 184, g: 115, b: 51 };
const SILVER_COLOR = { r: 192, g: 192, b: 192 };

// Wire path for anode: battery (+) down to anode
const ANODE_WIRE_POINTS = [
  { x: 350, y: 120 },   // Battery + terminal
  { x: 280, y: 200 },   // Down and left
  { x: 200, y: 350 },   // To anode
];

// Wire path for cathode: battery (-) down to cathode
const CATHODE_WIRE_POINTS = [
  { x: 650, y: 120 },   // Battery - terminal
  { x: 720, y: 200 },   // Down and right
  { x: 800, y: 350 },   // To cathode
];

function getPointOnPath(points: { x: number; y: number }[], progress: number): { x: number; y: number } {
  if (progress <= 0) return points[0];
  if (progress >= 1) return points[points.length - 1];
  
  const totalSegments = points.length - 1;
  const segmentProgress = progress * totalSegments;
  const segmentIndex = Math.floor(segmentProgress);
  const localProgress = segmentProgress - segmentIndex;
  
  const startPoint = points[Math.min(segmentIndex, points.length - 1)];
  const endPoint = points[Math.min(segmentIndex + 1, points.length - 1)];
  
  return {
    x: startPoint.x + (endPoint.x - startPoint.x) * localProgress,
    y: startPoint.y + (endPoint.y - startPoint.y) * localProgress,
  };
}

function getProgressFromDrag(
  points: { x: number; y: number }[],
  dragX: number,
  dragY: number,
  currentProgress: number
): number {
  let minDist = Infinity;
  let bestProgress = currentProgress;
  
  for (let p = 0; p <= 1; p += 0.02) {
    const point = getPointOnPath(points, p);
    const dist = Math.sqrt((point.x - dragX) ** 2 + (point.y - dragY) ** 2);
    if (dist < minDist) {
      minDist = dist;
      bestProgress = p;
    }
  }
  
  return Math.max(currentProgress, bestProgress);
}

function createPathD(points: { x: number; y: number }[]): string {
  if (points.length < 2) return '';
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    d += ` Q ${(points[i - 1].x + points[i].x) / 2 + 30} ${points[i - 1].y} ${points[i].x} ${points[i].y}`;
  }
  return d;
}

export default function ElectroplatingGame() {
  const [anodeMass, setAnodeMass] = useState(ANODE_START_MASS);
  const [cathodeMass, setCathodeMass] = useState(CATHODE_START_MASS);
  const [ions, setIons] = useState<Particle[]>([]);
  const [electrons, setElectrons] = useState<Particle[]>([]);
  const [platedCount, setPlatedCount] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  
  const [isAnodeConnected, setIsAnodeConnected] = useState(false);
  const [isCathodeConnected, setIsCathodeConnected] = useState(false);

  const { toast } = useToast();
  
  const cathodeRef = useRef<HTMLDivElement>(null);
  const anodeRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const getRingColor = () => {
    const progress = platedCount / TOTAL_PLATING_GOAL;
    const r = Math.round(COPPER_COLOR.r + (SILVER_COLOR.r - COPPER_COLOR.r) * progress);
    const g = Math.round(COPPER_COLOR.g + (SILVER_COLOR.g - COPPER_COLOR.g) * progress);
    const b = Math.round(COPPER_COLOR.b + (SILVER_COLOR.b - COPPER_COLOR.b) * progress);
    return `rgb(${r}, ${g}, ${b})`;
  };

  const getPlatingGradient = () => {
    const progress = platedCount / TOTAL_PLATING_GOAL;
    const silverPercent = Math.round(progress * 100);
    const copperColor = `rgb(${COPPER_COLOR.r}, ${COPPER_COLOR.g}, ${COPPER_COLOR.b})`;
    const silverColor = `rgb(${SILVER_COLOR.r}, ${SILVER_COLOR.g}, ${SILVER_COLOR.b})`;
    
    return `conic-gradient(from 0deg, ${silverColor} 0deg, ${silverColor} ${silverPercent * 3.6}deg, ${copperColor} ${silverPercent * 3.6}deg, ${copperColor} 360deg)`;
  };

  const spawnIon = () => {
    if (!isAnodeConnected || !isCathodeConnected) {
      toast({
        title: "Circuit Open",
        description: "Connect the wires to the battery first!",
        variant: "destructive"
      });
      return;
    }

    if (anodeMass <= 10) {
      toast({
        title: "Anode Depleted",
        description: "The silver anode has run out of material!",
        variant: "destructive"
      });
      return;
    }
    
    const newIon: Particle = {
      id: `ion-${Date.now()}`,
      type: 'ion',
      x: 0, 
      y: 0,
      status: 'active'
    };

    const startPoint = ANODE_WIRE_POINTS[0];
    const newAnodeElectron: Particle = {
      id: `ae-${Date.now()}`,
      type: 'anode_electron',
      x: startPoint.x,
      y: startPoint.y,
      status: 'active',
      segment: 'anode_wire',
      progress: 0
    };
    
    setIons(prev => [...prev, newIon]);
    setElectrons(prev => [...prev, newAnodeElectron]);
    setAnodeMass(prev => prev - MASS_PER_UNIT);
  };

  const handleIonDragEnd = (id: string, info: any) => {
    const cathodeRect = cathodeRef.current?.getBoundingClientRect();
    const dropPoint = info.point;
    const hasWaitingElectron = electrons.some(e => e.status === 'waiting');

    if (cathodeRect && 
        dropPoint.x >= cathodeRect.left && 
        dropPoint.x <= cathodeRect.right && 
        dropPoint.y >= cathodeRect.top && 
        dropPoint.y <= cathodeRect.bottom &&
        hasWaitingElectron) {
      
      setIons(prev => prev.map(p => p.id === id ? { ...p, status: 'waiting' } : p));
    } else if (cathodeRect && 
        dropPoint.x >= cathodeRect.left && 
        dropPoint.x <= cathodeRect.right && 
        dropPoint.y >= cathodeRect.top && 
        dropPoint.y <= cathodeRect.bottom &&
        !hasWaitingElectron) {
      toast({
        title: "Wait for Electron",
        description: "An electron must be at the cathode first!",
        variant: "destructive",
        duration: 1500
      });
    }
  };

  const handleElectronDrag = useCallback((id: string, info: any) => {
    const svgRect = svgRef.current?.getBoundingClientRect();
    if (!svgRect) return;
    
    const svgX = (info.point.x - svgRect.left) * (1000 / svgRect.width);
    const svgY = (info.point.y - svgRect.top) * (600 / svgRect.height);
    
    setElectrons(prev => prev.map(electron => {
      if (electron.id !== id) return electron;
      
      const points = electron.segment === 'anode_wire' ? ANODE_WIRE_POINTS : CATHODE_WIRE_POINTS;
      const newProgress = getProgressFromDrag(points, svgX, svgY, electron.progress || 0);
      const newPos = getPointOnPath(points, newProgress);
      
      return {
        ...electron,
        x: newPos.x,
        y: newPos.y,
        progress: newProgress
      };
    }));
  }, []);

  const handleElectronDragEnd = useCallback((id: string) => {
    setElectrons(prev => {
      const electron = prev.find(e => e.id === id);
      if (!electron) return prev;
      
      if (electron.segment === 'anode_wire' && (electron.progress || 0) >= 0.95) {
        const filtered = prev.filter(e => e.id !== id);
        const startPoint = CATHODE_WIRE_POINTS[0];
        const newCathodeElectron: Particle = {
          id: `ce-${Date.now()}`,
          type: 'cathode_electron',
          x: startPoint.x,
          y: startPoint.y,
          status: 'active',
          segment: 'cathode_wire',
          progress: 0
        };
        
        toast({
          title: "Circuit Active",
          description: "Electron passed through battery!",
          duration: 1000,
          className: "bg-yellow-500/10 border-yellow-500/30 text-yellow-200 h-12"
        });
        
        return [...filtered, newCathodeElectron];
      }
      
      if (electron.segment === 'cathode_wire' && (electron.progress || 0) >= 0.95) {
        return prev.map(e => 
          e.id === id ? { ...e, status: 'waiting' as const, progress: 1 } : e
        );
      }
      
      return prev;
    });
  }, [toast]);

  useEffect(() => {
    const waitingIons = ions.filter(i => i.status === 'waiting');
    const waitingElectrons = electrons.filter(e => e.status === 'waiting');

    if (waitingIons.length > 0 && waitingElectrons.length > 0) {
      const pairs = Math.min(waitingIons.length, waitingElectrons.length);
      
      if (pairs > 0) {
        const usedIonIds = waitingIons.slice(0, pairs).map(i => i.id);
        const usedElectronIds = waitingElectrons.slice(0, pairs).map(e => e.id);

        setIons(prev => prev.filter(p => !usedIonIds.includes(p.id)));
        setElectrons(prev => prev.filter(p => !usedElectronIds.includes(p.id)));
        
        setCathodeMass(prev => prev + (MASS_PER_UNIT * pairs));
        
        setPlatedCount(prev => {
          const newCount = prev + pairs;
          if (newCount >= TOTAL_PLATING_GOAL) {
            setShowSuccess(true);
          }
          return newCount;
        });
        
        toast({
          title: "Plating Successful!",
          description: "Silver ion reduced to solid silver on the cathode.",
          duration: 1500,
          className: "bg-green-500/20 border-green-500/50 text-green-100"
        });
      }
    }
  }, [ions, electrons, toast]);

  const resetGame = () => {
    setAnodeMass(ANODE_START_MASS);
    setCathodeMass(CATHODE_START_MASS);
    setIons([]);
    setElectrons([]);
    setPlatedCount(0);
    setShowSuccess(false);
    setIsAnodeConnected(false);
    setIsCathodeConnected(false);
  };

  return (
    <div className="min-h-screen w-full bg-white text-slate-900 p-4 md:p-8 font-sans overflow-hidden flex flex-col items-center">
      
      <header className="w-full max-w-6xl flex justify-between items-center mb-8 z-10">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold tracking-wider text-slate-900">
            ELECTROPLATING LAB
          </h1>
          <p className="text-slate-600 text-sm mt-1 flex items-center gap-2">
            <FlaskConical size={14} /> Ag (Silver) → Cu (Copper)
          </p>
        </div>
        
        <div className="flex gap-3">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full bg-slate-100 border-slate-300 hover:bg-slate-200">
                  <Info size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs bg-slate-900 border-slate-700 text-slate-100 p-4">
                <p className="mb-2 font-semibold">How to play:</p>
                <ol className="list-decimal list-inside space-y-1 text-xs">
                  <li>Drag the <strong>Wires</strong> to connect Anode & Cathode to Battery.</li>
                  <li>Click Anode to release <strong>Ag⁺ Ion</strong> & <strong>Electron (e⁻)</strong>.</li>
                  <li>Drag <strong>e⁻</strong> along the wire to the Battery.</li>
                  <li>Drag <strong>e⁻</strong> from Battery along wire to Copper Ring.</li>
                  <li>Drag <strong>Ag⁺</strong> from solution to Copper Ring.</li>
                  <li>Watch the ring gradually turn silver!</li>
                </ol>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Button variant="outline" size="icon" onClick={resetGame} className="rounded-full bg-slate-100 border-slate-300 hover:bg-slate-200">
            <RefreshCw size={18} />
          </Button>
        </div>
      </header>

      <main className="flex-1 w-full max-w-6xl grid grid-cols-1 lg:grid-cols-4 gap-6 items-start relative">
        
        <div className="lg:col-span-1 flex flex-col gap-6 order-2 lg:order-1">
          
          <Card className="bg-slate-50 border-slate-200 p-6 space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">Electrode Status</h3>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-gradient-to-br from-gray-100 to-gray-400"/> Silver Anode</span>
                    <span className="font-mono">{anodeMass}g</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-gray-400 to-gray-600"
                      initial={{ width: '100%' }}
                      animate={{ width: `${(anodeMass / ANODE_START_MASS) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-600">Source of Ag⁺ ions</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <motion.div 
                        className="w-3 h-3 rounded-full"
                        animate={{ backgroundColor: getRingColor() }}
                      />
                      Copper Ring
                    </span>
                    <span className="font-mono">{cathodeMass}g</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full"
                      style={{ background: `linear-gradient(to right, ${getRingColor()}, ${getRingColor()})` }}
                      initial={{ width: '50%' }}
                      animate={{ width: `${(cathodeMass / (CATHODE_START_MASS + ANODE_START_MASS)) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-600">Target for plating ({Math.round((platedCount / TOTAL_PLATING_GOAL) * 100)}% silver coated)</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="bg-slate-50 border-slate-200 p-4">
            <div className="flex items-center gap-2 mb-3 text-slate-700">
              <Microscope size={16} />
              <h3 className="text-sm font-semibold uppercase tracking-wider">Atomic View</h3>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-100 p-3 rounded-md border border-slate-300">
                <div className="text-[10px] text-center mb-2 text-slate-600">Silver Anode Surface</div>
                <div className="grid grid-cols-4 gap-1">
                  {Array.from({ length: 16 }).map((_, i) => {
                    const isGone = i >= Math.ceil((anodeMass / ANODE_START_MASS) * 16);
                    return (
                      <motion.div 
                        key={i}
                        className={`w-3 h-3 rounded-full ${isGone ? 'bg-slate-800/30' : 'bg-gradient-to-br from-gray-200 to-gray-400'}`}
                        animate={{ scale: isGone ? 0.5 : 1, opacity: isGone ? 0.2 : 1 }}
                      />
                    )
                  })}
                </div>
              </div>

              <div className="bg-slate-100 p-3 rounded-md border border-slate-300">
                <div className="text-[10px] text-center mb-2 text-slate-600">Cathode Surface</div>
                <div className="grid grid-cols-4 gap-1">
                  {Array.from({ length: 16 }).map((_, i) => {
                    const isPlated = i < Math.min(16, Math.floor(platedCount * 2.7));
                    return (
                      <div key={i} className="relative w-3 h-3">
                        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-orange-400 to-orange-700 opacity-80" />
                        
                        {isPlated && (
                          <motion.div 
                            className="absolute inset-0 rounded-full bg-gradient-to-br from-gray-100 to-white shadow-sm z-10"
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", stiffness: 300, damping: 20 }}
                          />
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
            <div className="mt-3 text-[10px] text-slate-600 text-center leading-tight">
              Atoms transfer from the anode lattice to the cathode surface.
            </div>
          </Card>
        </div>

        <div className="lg:col-span-3 relative h-[600px] flex flex-col items-center justify-start order-1 lg:order-2 select-none">
          
          <svg 
            ref={svgRef}
            className="absolute inset-0 w-full h-full" 
            viewBox="0 0 1000 600" 
            preserveAspectRatio="xMidYMid meet"
            style={{ zIndex: 5 }}
          >
            {/* Anode wire path */}
            {isAnodeConnected && (
              <path 
                d={createPathD(ANODE_WIRE_POINTS)}
                fill="none" 
                stroke="#444444" 
                strokeWidth="12" 
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}
            
            {/* Cathode wire path */}
            {isCathodeConnected && (
              <path 
                d={createPathD(CATHODE_WIRE_POINTS)}
                fill="none" 
                stroke="#444444" 
                strokeWidth="12" 
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            )}
          </svg>

          {/* Battery at top center */}
          <div className="absolute top-8 left-1/2 -translate-x-1/2 z-20 bg-slate-100 p-3 rounded-lg border-2 border-slate-400 shadow-lg">
            <div className="flex items-center gap-3 px-3">
              <div className="flex flex-col items-center">
                <span className="text-red-600 font-bold text-base">+</span>
                <div className="w-3 h-3 rounded-full bg-red-500 mt-0.5 border border-red-600"></div>
              </div>
              <Battery className="text-slate-800 w-10 h-10 rotate-90" />
              <div className="flex flex-col items-center">
                <span className="text-blue-600 font-bold text-base">-</span>
                <div className="w-3 h-3 rounded-full bg-blue-500 mt-0.5 border border-blue-600"></div>
              </div>
            </div>
            <div className="text-[9px] font-mono text-slate-600 text-center">DC POWER</div>
          </div>

          {/* Wire handles */}
          {!isAnodeConnected && (
            <motion.div 
              drag
              dragMomentum={false}
              onDragEnd={(e, info) => {
                const anodeRect = anodeRef.current?.getBoundingClientRect();
                if (anodeRect && 
                    info.point.x >= anodeRect.left - 50 && 
                    info.point.x <= anodeRect.right + 50 && 
                    info.point.y >= anodeRect.top - 50 && 
                    info.point.y <= anodeRect.bottom + 50) {
                  setIsAnodeConnected(true);
                  toast({ title: "Anode Connected", description: "Wire attached to silver anode." });
                }
              }}
              className="absolute top-24 left-[20%] z-50 cursor-grab active:cursor-grabbing"
              whileHover={{ scale: 1.1 }}
            >
              <div className="flex items-center gap-2 bg-slate-600 px-3 py-1 rounded-full border border-slate-500 shadow-lg text-white text-xs">
                <Plug size={12} /> Wire to Anode
              </div>
            </motion.div>
          )}

          {!isCathodeConnected && (
            <motion.div 
              drag
              dragMomentum={false}
              onDragEnd={(e, info) => {
                const cathodeRect = cathodeRef.current?.getBoundingClientRect();
                if (cathodeRect && 
                    info.point.x >= cathodeRect.left - 50 && 
                    info.point.x <= cathodeRect.right + 50 && 
                    info.point.y >= cathodeRect.top - 50 && 
                    info.point.y <= cathodeRect.bottom + 50) {
                  setIsCathodeConnected(true);
                  toast({ title: "Cathode Connected", description: "Wire attached to copper ring." });
                }
              }}
              className="absolute top-24 right-[20%] z-50 cursor-grab active:cursor-grabbing"
              whileHover={{ scale: 1.1 }}
            >
              <div className="flex items-center gap-2 bg-slate-600 px-3 py-1 rounded-full border border-slate-500 shadow-lg text-white text-xs">
                <Plug size={12} /> Wire to Cathode
              </div>
            </motion.div>
          )}

          {/* Beaker */}
          <div className="relative w-full max-w-2xl h-80 mt-32">
            <div className="absolute inset-0 border-4 border-slate-400 border-t-0 rounded-b-3xl bg-blue-50 backdrop-blur-sm overflow-hidden">
              <div className="absolute bottom-0 left-0 right-0 h-[80%] liquid-surface animate-pulse opacity-40 bg-blue-100">
                <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.2) 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
              </div>
            </div>

            {/* Electrodes */}
            <div className="absolute inset-0 flex justify-between px-16 pt-6">
              
              {/* Anode */}
              <div className="relative group flex flex-col items-center" ref={anodeRef}>
                {isAnodeConnected && (
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-gray-600 border-2 border-gray-500 z-20"></div>
                )}
                
                <motion.div 
                  className="relative w-14 metallic-silver rounded-sm shadow-lg cursor-pointer border border-white/20 z-10 overflow-hidden"
                  style={{ height: 200 }} 
                  animate={{ 
                    width: 56 * (anodeMass / ANODE_START_MASS),
                  }} 
                  onClick={spawnIon}
                >
                  <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }}></div>
                  
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                    <span className="text-xs font-bold text-white text-center">Click</span>
                  </div>
                </motion.div>
                <div className="text-center mt-2 text-xs font-bold text-slate-500">Silver Anode</div>
              </div>

              {/* Cathode */}
              <div className="relative flex flex-col items-center" ref={cathodeRef}>
                {isCathodeConnected && (
                  <div className="absolute top-6 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-gray-600 border-2 border-gray-500 z-20"></div>
                )}
                
                <motion.div 
                  className="relative w-20 h-20 rounded-full shadow-lg z-10 flex items-center justify-center"
                  style={{ 
                    marginTop: 40,
                    background: getPlatingGradient(),
                  }}
                >
                  <div className="w-12 h-12 rounded-full bg-blue-50" />
                  
                  {ions.filter(p => p.status === 'waiting').map((p, i) => (
                    <motion.div
                      key={p.id}
                      className="absolute w-2.5 h-2.5 rounded-full bg-slate-300 border border-slate-400 opacity-70"
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      style={{ 
                        transform: `rotate(${i * 60}deg) translate(32px)`,
                        zIndex: 25
                      }}
                    />
                  ))}
                  
                  {electrons.filter(p => p.status === 'waiting').map((p, i) => (
                    <motion.div
                      key={p.id}
                      className="absolute w-2 h-2 rounded-full bg-yellow-400 border border-yellow-500"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5, delay: 0.3 }}
                      style={{ 
                        transform: `rotate(${i * 60 + 30}deg) translate(32px)`,
                        zIndex: 25
                      }}
                    />
                  ))}
                </motion.div>

                <div className="text-center mt-6 text-xs font-bold" style={{ color: getRingColor() }}>
                  {platedCount >= TOTAL_PLATING_GOAL ? 'Silver Plated Ring' : 'Copper Ring'}
                </div>
              </div>
            </div>

            {/* Ions */}
            <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 30 }}>
              <AnimatePresence>
                {ions.map((ion) => ion.status === 'active' && (
                  <motion.div
                    key={ion.id}
                    initial={{ x: 70, y: 100, opacity: 0, scale: 0 }}
                    animate={{ 
                      opacity: 1, 
                      scale: 1,
                      y: [100, 110, 90, 100] 
                    }} 
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ 
                      y: { repeat: Infinity, duration: 4, ease: "easeInOut" } 
                    }}
                    drag={true} 
                    dragConstraints={{ left: 0, right: 350, top: 0, bottom: 200 }}
                    dragElastic={0.1}
                    dragMomentum={false}
                    onDragEnd={(e, info) => handleIonDragEnd(ion.id, info)}
                    className="absolute w-8 h-8 rounded-full bg-gradient-to-br from-slate-100 to-slate-300 border border-slate-400 shadow-[0_0_8px_rgba(255,255,255,0.5)] flex items-center justify-center pointer-events-auto cursor-grab active:cursor-grabbing"
                    style={{ touchAction: 'none' }}
                  >
                    <div className="text-[10px] font-bold text-slate-700 select-none flex flex-col items-center leading-none">
                      <span>Ag</span>
                      <span className="text-[7px] absolute top-0.5 right-0.5">+</span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Electrons on wire */}
          <svg 
            className="absolute inset-0 w-full h-full pointer-events-none" 
            viewBox="0 0 1000 600" 
            preserveAspectRatio="xMidYMid meet"
            style={{ zIndex: 40 }}
          >
            <AnimatePresence>
              {electrons.filter(e => e.status === 'active').map((electron) => (
                <motion.g
                  key={electron.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  style={{ pointerEvents: 'auto' }}
                >
                  <motion.circle
                    cx={electron.x}
                    cy={electron.y}
                    r="12"
                    fill="#FACC15"
                    stroke="#EAB308"
                    strokeWidth="2.5"
                    style={{ 
                      cursor: 'grab',
                      filter: 'drop-shadow(0 0 6px rgba(253, 224, 71, 0.8))'
                    }}
                    drag
                    dragMomentum={false}
                    dragElastic={0}
                    onDrag={(e, info) => handleElectronDrag(electron.id, info)}
                    onDragEnd={() => handleElectronDragEnd(electron.id)}
                    whileHover={{ r: 14, filter: 'drop-shadow(0 0 10px rgba(253, 224, 71, 1))' }}
                    whileDrag={{ cursor: 'grabbing' }}
                  />
                  <motion.text
                    x={electron.x}
                    y={electron.y + 3}
                    textAnchor="middle"
                    fontSize="9"
                    fontWeight="bold"
                    fill="#854D0E"
                    style={{ pointerEvents: 'none', userSelect: 'none' }}
                  >
                    e⁻
                  </motion.text>
                </motion.g>
              ))}
            </AnimatePresence>
          </svg>
        </div>
      </main>

      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="bg-slate-900 border-slate-700 text-slate-100">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-400 text-2xl">
              <Trophy size={24} /> Electroplating Complete!
            </DialogTitle>
            <DialogDescription className="text-slate-400 pt-2 text-lg">
              Copper ring has been successfully electroplated with silver!
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700 text-sm">
              <p className="mb-2"><strong>Summary:</strong></p>
              <ul className="list-disc list-inside space-y-1 text-slate-400">
                <li>Silver Anode mass consumed: {ANODE_START_MASS - anodeMass}g</li>
                <li>Silver coating applied: {platedCount} units</li>
                <li>Ring is now fully silver colored!</li>
              </ul>
            </div>
            <Button onClick={resetGame} className="w-full bg-primary hover:bg-primary/90 text-white font-bold">
              Start New Experiment
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
