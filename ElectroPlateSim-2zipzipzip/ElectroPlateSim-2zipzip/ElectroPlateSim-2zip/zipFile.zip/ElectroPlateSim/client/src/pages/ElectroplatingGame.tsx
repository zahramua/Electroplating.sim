import React, { useState, useRef, useEffect } from 'react';
import { motion, useDragControls, AnimatePresence } from 'framer-motion';
import { ArrowRight, Battery, RefreshCw, Info, FlaskConical, Zap, Atom, Microscope, Trophy, Plug } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

// --- Types ---
type ParticleType = 'ion' | 'electron' | 'anode_electron';
type ElectronPhase = 'at_anode' | 'traveling_to_battery' | 'at_battery' | 'traveling_to_cathode' | 'at_cathode';
interface Particle {
  id: string;
  type: ParticleType;
  x: number;
  y: number;
  status: 'active' | 'waiting' | 'plated';
  phase?: ElectronPhase;
}

// --- Constants ---
const ANODE_START_MASS = 50;
const CATHODE_START_MASS = 25;
const MASS_PER_UNIT = 5;
const TOTAL_PLATING_GOAL = 6; // Lowered goal as requested

export default function ElectroplatingGame() {
  const [anodeMass, setAnodeMass] = useState(ANODE_START_MASS);
  const [cathodeMass, setCathodeMass] = useState(CATHODE_START_MASS);
  const [ions, setIons] = useState<Particle[]>([]);
  const [electrons, setElectrons] = useState<Particle[]>([]);
  const [platedCount, setPlatedCount] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);
  
  // Wiring State
  const [isAnodeConnected, setIsAnodeConnected] = useState(false);
  const [isCathodeConnected, setIsCathodeConnected] = useState(false);

  const { toast } = useToast();
  
  // Refs for drop zones
  const cathodeRef = useRef<HTMLDivElement>(null);
  const batteryRef = useRef<HTMLDivElement>(null);
  const anodeRef = useRef<HTMLDivElement>(null);

  // --- Game Logic ---

  const spawnIon = () => {
    if (!isAnodeConnected || !isCathodeConnected) {
      toast({
        title: "Circuit Open",
        description: "Connect the wires to the battery first!",
        variant: "destructive"
      });
      return;
    }

    if (anodeMass <= 10) {
      toast({
        title: "Anode Depleted",
        description: "The silver anode has run out of material!",
        variant: "destructive"
      });
      return;
    }
    
    const newIon: Particle = {
      id: `ion-${Date.now()}`,
      type: 'ion',
      x: 0, 
      y: 0,
      status: 'active'
    };

    // Spawn an electron at the anode wire connection (top of anode)
    const newAnodeElectron: Particle = {
        id: `ae-${Date.now()}`,
        type: 'anode_electron',
        x: 0,
        y: -120, 
        status: 'active',
        phase: 'at_anode'
    };
    
    setIons(prev => [...prev, newIon]);
    setElectrons(prev => [...prev, newAnodeElectron]);
    setAnodeMass(prev => prev - MASS_PER_UNIT);
    setCathodeMass(prev => prev + MASS_PER_UNIT);
  };

  const spawnCathodeElectron = () => {
    const newElectron: Particle = {
      id: `e-${Date.now()}`,
      type: 'electron',
      x: 0,
      y: 0,
      status: 'active'
    };
    setElectrons(prev => [...prev, newElectron]);
  };

  const handleIonDragEnd = (id: string, info: any) => {
    // Check if dropped on cathode AND there's a waiting electron
    const cathodeRect = cathodeRef.current?.getBoundingClientRect();
    const dropPoint = info.point;
    const hasWaitingElectron = electrons.some(e => e.status === 'waiting');

    if (cathodeRect && 
        dropPoint.x >= cathodeRect.left && 
        dropPoint.x <= cathodeRect.right && 
        dropPoint.y >= cathodeRect.top && 
        dropPoint.y <= cathodeRect.bottom &&
        hasWaitingElectron) {
      
      // Mark as waiting at cathode
      setIons(prev => prev.map(p => p.id === id ? { ...p, status: 'waiting' } : p));
    } else if (cathodeRect && 
        dropPoint.x >= cathodeRect.left && 
        dropPoint.x <= cathodeRect.right && 
        dropPoint.y >= cathodeRect.top && 
        dropPoint.y <= cathodeRect.bottom &&
        !hasWaitingElectron) {
      toast({
        title: "Wait for Electron",
        description: "An electron must be at the cathode first!",
        variant: "destructive",
        duration: 1500
      });
    }
  };

  const handleElectronDragEnd = (id: string, info: any, type: ParticleType) => {
    const dropPoint = info.point;

    if (type === 'anode_electron') {
        // Check if dropped on Battery - must be on +ve side (left)
        const batteryRect = batteryRef.current?.getBoundingClientRect();
        if (batteryRect && 
            dropPoint.x >= batteryRect.left && 
            dropPoint.x <= batteryRect.right && 
            dropPoint.y >= batteryRect.top && 
            dropPoint.y <= batteryRect.bottom) {
            
            // Remove anode electron and spawn cathode electron on the right (-ve) side
            setElectrons(prev => {
              const filtered = prev.filter(p => p.id !== id);
              const newCathodeElectron: Particle = {
                id: `ce-${Date.now()}`,
                type: 'electron',
                x: 80, // Start on the right side (-ve side) of battery
                y: -120,
                status: 'active',
                phase: 'at_battery'
              };
              return [...filtered, newCathodeElectron];
            });
            toast({
                title: "Circuit Active",
                description: "Electron moved through the battery!",
                duration: 1000,
                className: "bg-yellow-500/10 border-yellow-500/30 text-yellow-200 h-12"
            });
        }
    } else {
        // Check if dropped on Cathode
        const cathodeRect = cathodeRef.current?.getBoundingClientRect();
        if (cathodeRect && 
            dropPoint.x >= cathodeRect.left && 
            dropPoint.x <= cathodeRect.right && 
            dropPoint.y >= cathodeRect.top && 
            dropPoint.y <= cathodeRect.bottom) {
          
          setElectrons(prev => prev.map(p => p.id === id ? { ...p, status: 'waiting', phase: 'at_cathode' } : p));
        }
    }
  };

  useEffect(() => {
    const waitingIons = ions.filter(i => i.status === 'waiting');
    const waitingElectrons = electrons.filter(e => e.status === 'waiting');

    if (waitingIons.length > 0 && waitingElectrons.length > 0) {
      // Match them up
      const pairs = Math.min(waitingIons.length, waitingElectrons.length);
      
      if (pairs > 0) {
        // Remove utilized particles
        const usedIonIds = waitingIons.slice(0, pairs).map(i => i.id);
        const usedElectronIds = waitingElectrons.slice(0, pairs).map(e => e.id);

        setIons(prev => prev.filter(p => !usedIonIds.includes(p.id)));
        setElectrons(prev => prev.filter(p => !usedElectronIds.includes(p.id)));
        
        setPlatedCount(prev => {
            const newCount = prev + pairs;
            if (newCount >= TOTAL_PLATING_GOAL) {
                setShowSuccess(true);
            }
            return newCount;
        });
        
        toast({
          title: "Plating Successful!",
          description: "Silver ion reduced to solid silver on the cathode.",
          duration: 1500,
          className: "bg-green-500/20 border-green-500/50 text-green-100"
        });
      }
    }
  }, [ions, electrons, toast]);

  const resetGame = () => {
    setAnodeMass(ANODE_START_MASS);
    setCathodeMass(CATHODE_START_MASS);
    setIons([]);
    setElectrons([]);
    setPlatedCount(0);
    setShowSuccess(false);
    setIsAnodeConnected(false);
    setIsCathodeConnected(false);
  };

  return (
    <div className="min-h-screen w-full bg-white text-slate-900 p-4 md:p-8 font-sans overflow-hidden flex flex-col items-center">
      
      {/* --- Header --- */}
      <header className="w-full max-w-5xl flex justify-between items-center mb-8 z-10">
        <div>
          <h1 className="text-3xl md:text-4xl font-display font-bold tracking-wider text-slate-900">
            ELECTROPLATING LAB
          </h1>
          <p className="text-slate-600 text-sm mt-1 flex items-center gap-2">
            <FlaskConical size={14} /> Ag (Silver) → Cu (Copper)
          </p>
        </div>
        
        <div className="flex gap-3">
           <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full bg-slate-100 border-slate-300 hover:bg-slate-200">
                  <Info size={18} />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs bg-slate-900 border-slate-700 text-slate-100 p-4">
                <p className="mb-2 font-semibold">How to play:</p>
                <ol className="list-decimal list-inside space-y-1 text-xs">
                  <li>Drag the <strong>Wires</strong> to connect Anode & Cathode to Battery.</li>
                  <li>Click Anode to release <strong>Ag⁺ Ion</strong> & <strong>Electron (e⁻)</strong>.</li>
                  <li>Drag <strong>e⁻</strong> from Anode Wire → Battery to charge circuit.</li>
                  <li>Drag <strong>e⁻</strong> from Battery → Copper Ring.</li>
                  <li>Drag <strong>Ag⁺</strong> from solution → Copper Ring.</li>
                  <li>Wait for them to combine and plate!</li>
                </ol>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Button variant="outline" size="icon" onClick={resetGame} className="rounded-full bg-slate-100 border-slate-300 hover:bg-slate-200">
            <RefreshCw size={18} />
          </Button>
        </div>
      </header>

      {/* --- Main Lab Bench --- */}
      <main className="flex-1 w-full max-w-5xl grid grid-cols-1 lg:grid-cols-3 gap-6 items-start relative">
        
        {/* Left: Atomic View & Stats */}
        <div className="lg:col-span-1 flex flex-col gap-6 order-2 lg:order-1">
          
          {/* Stats Panel */}
          <Card className="bg-slate-50 border-slate-200 p-6 space-y-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider mb-4">Electrode Status</h3>
              
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-gradient-to-br from-gray-100 to-gray-400"/> Silver Anode</span>
                    <span className="font-mono">{anodeMass}g</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-gray-400 to-gray-600"
                      initial={{ width: '100%' }}
                      animate={{ width: `${(anodeMass / ANODE_START_MASS) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-600">Source of Ag⁺ ions</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-gradient-to-br from-orange-300 to-orange-600"/> Copper Ring</span>
                    <span className="font-mono">{cathodeMass}g</span>
                  </div>
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-gradient-to-r from-orange-400 to-orange-600"
                      initial={{ width: '50%' }}
                      animate={{ width: `${(cathodeMass / (CATHODE_START_MASS + ANODE_START_MASS)) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-600">Target for plating</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Atomic Micro View (New) */}
          <Card className="bg-slate-50 border-slate-200 p-4">
            <div className="flex items-center gap-2 mb-3 text-slate-700">
              <Microscope size={16} />
              <h3 className="text-sm font-semibold uppercase tracking-wider">Atomic View</h3>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              {/* Anode Atoms */}
              <div className="bg-slate-100 p-3 rounded-md border border-slate-300">
                <div className="text-[10px] text-center mb-2 text-slate-600">Silver Anode Surface</div>
                <div className="grid grid-cols-4 gap-1">
                  {Array.from({ length: 16 }).map((_, i) => {
                    const isGone = i >= Math.ceil((anodeMass / ANODE_START_MASS) * 16);
                    return (
                      <motion.div 
                        key={i}
                        className={`w-3 h-3 rounded-full ${isGone ? 'bg-slate-800/30' : 'bg-gradient-to-br from-gray-200 to-gray-400'}`}
                        animate={{ scale: isGone ? 0.5 : 1, opacity: isGone ? 0.2 : 1 }}
                      />
                    )
                  })}
                </div>
              </div>

              {/* Cathode Atoms */}
              <div className="bg-slate-100 p-3 rounded-md border border-slate-300">
                 <div className="text-[10px] text-center mb-2 text-slate-600">Cathode Surface</div>
                 <div className="grid grid-cols-4 gap-1">
                  {Array.from({ length: 16 }).map((_, i) => {
                    const isPlated = i < Math.min(16, Math.floor(platedCount * 2.7)); // Adjusted visual ratio
                    return (
                      <div key={i} className="relative w-3 h-3">
                        {/* Base Copper Atom */}
                        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-orange-400 to-orange-700 opacity-80" />
                        
                        {/* Plated Silver Atom Overlay */}
                        {isPlated && (
                          <motion.div 
                            className="absolute inset-0 rounded-full bg-gradient-to-br from-gray-100 to-white shadow-sm z-10"
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", stiffness: 300, damping: 20 }}
                          />
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
            <div className="mt-3 text-[10px] text-slate-600 text-center leading-tight">
              Atoms transfer from the anode lattice to the cathode surface.
            </div>
          </Card>

        </div>

        {/* Center: The Apparatus */}
        <div className="lg:col-span-2 relative h-[600px] flex flex-col items-center justify-start pt-10 order-1 lg:order-2 select-none">
          
          {/* Wiring & Battery */}
          <div className="absolute top-0 left-0 right-0 h-32 flex justify-center items-start pointer-events-none">
             {/* Wires Layer */}
             <svg className="absolute top-0 w-full h-[600px]" style={{ zIndex: 1, pointerEvents: 'none' }} viewBox="0 0 1000 600" preserveAspectRatio="none">
                
                {/* Positive Wire (to Anode) - LEFT side of battery attached directly - WAVY - Only show when connected */}
                {isAnodeConnected && (
                  <path d="M 320 70 Q 280 110, 240 160" fill="none" stroke="#999999" strokeWidth="8" strokeLinecap="round" opacity="1" />
                )}
                
                {/* Negative Wire (to Cathode) - RIGHT side of battery attached directly - WAVY - Only show when connected */}
                {isCathodeConnected && (
                  <path d="M 680 70 Q 720 110, 760 160" fill="none" stroke="#999999" strokeWidth="8" strokeLinecap="round" opacity="1" />
                )}
                
                {/* Circuit Arrows (Animated) */}
                {isAnodeConnected && isCathodeConnected && (
                    <>
                    <motion.circle r="3" fill="#FACC15" opacity={0.6}>
                      <animateMotion 
                         dur="3s" 
                         repeatCount="indefinite" 
                         path="M 25% 160 L 25% 70 L 42% 70" // Electron flow: Anode -> Battery (positive left side)
                         keyPoints="0;1"
                         keyTimes="0;1"
                      />
                    </motion.circle>

                    <motion.circle r="3" fill="#FACC15" opacity={0.6}>
                      <animateMotion 
                         dur="3s" 
                         repeatCount="indefinite" 
                         path="M 58% 70 L 75% 70 L 75% 160" // Electron flow: Battery (negative right side) -> Cathode
                         keyPoints="0;1"
                         keyTimes="0;1"
                      />
                    </motion.circle>
                    </>
                )}
             </svg>
             
             {/* Battery Unit */}
             <div className="absolute top-8 left-1/2 -translate-x-1/2 z-10 bg-slate-100 p-4 rounded-lg border-2 border-slate-400 shadow-lg flex flex-col items-center gap-2 pointer-events-auto" ref={batteryRef}>
                <div className="flex items-center gap-4 px-2">
                  <span className="text-slate-700 font-bold text-lg">+</span>
                  <Battery className="text-slate-800 w-12 h-12 rotate-90" />
                  <span className="text-slate-700 font-bold text-lg">-</span>
                </div>
                <div className="text-[10px] font-mono text-slate-600">DC POWER SUPPLY</div>
             </div>

            {/* Draggable Wire Handles */}
            {!isAnodeConnected && (
                <motion.div 
                    drag
                    dragMomentum={false}
                    onDragEnd={(e, info) => {
                        const point = info.point;
                        // Check if dropped near Anode top (approx coordinates)
                        const anodeRect = anodeRef.current?.getBoundingClientRect();
                        if (anodeRect && 
                            point.x >= anodeRect.left - 100 && 
                            point.x <= anodeRect.right + 100 && 
                            point.y >= anodeRect.top - 150 && 
                            point.y <= anodeRect.bottom + 50) {
                            setIsAnodeConnected(true);
                            toast({ title: "Anode Connected", description: "Circuit path established." });
                        }
                    }}
                    className="absolute top-28 left-[42%] z-50 cursor-grab active:cursor-grabbing pointer-events-auto"
                    whileHover={{ scale: 1.1 }}
                >
                    <div className="flex items-center gap-2 bg-slate-600 px-3 py-1 rounded-full border border-slate-500 shadow-lg text-white">
                        <Plug size={14} /> <span className="text-xs">Connect Anode (+)</span>
                    </div>
                    {/* Dotted line to show origin */}
                    <div className="absolute bottom-full left-1/2 h-8 w-0.5 bg-slate-500/50 border-l border-dashed border-slate-400"></div>
                </motion.div>
            )}

            {!isCathodeConnected && (
                 <motion.div 
                    drag
                    dragMomentum={false}
                    onDragEnd={(e, info) => {
                        const point = info.point;
                        const cathodeRect = cathodeRef.current?.getBoundingClientRect();
                        if (cathodeRect && 
                            point.x >= cathodeRect.left - 100 && 
                            point.x <= cathodeRect.right + 100 && 
                            point.y >= cathodeRect.top - 150 && 
                            point.y <= cathodeRect.bottom + 50) {
                            setIsCathodeConnected(true);
                            toast({ title: "Cathode Connected", description: "Circuit path established." });
                        }
                    }}
                    className="absolute top-28 left-[58%] z-50 cursor-grab active:cursor-grabbing pointer-events-auto"
                    whileHover={{ scale: 1.1 }}
                >
                    <div className="flex items-center gap-2 bg-slate-600 px-3 py-1 rounded-full border border-slate-500 shadow-lg text-white">
                        <Plug size={14} /> <span className="text-xs">Connect Cathode (-)</span>
                    </div>
                     {/* Dotted line to show origin */}
                     <div className="absolute bottom-full left-1/2 h-8 w-0.5 bg-slate-500/50 border-l border-dashed border-slate-400"></div>
                </motion.div>
            )}

          </div>

          {/* Beaker Container */}
          <div className="relative w-full max-w-lg h-96 mt-40">
            {/* Glass Container */}
            <div className="absolute inset-0 border-4 border-slate-400 border-t-0 rounded-b-3xl bg-blue-50 backdrop-blur-sm overflow-hidden">
               {/* Electrolyte Liquid */}
               <div className="absolute bottom-0 left-0 right-0 h-[85%] liquid-surface animate-pulse opacity-40 bg-blue-100">
                  {/* Bubbles/Details in liquid */}
                  <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.2) 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
               </div>
            </div>

            {/* Electrodes Container */}
            <div className="absolute inset-0 flex justify-between px-20 pt-12">
              
              {/* Anode (Silver Bar) */}
              <div className="relative group flex flex-col items-center" ref={anodeRef}>
                {/* The Electrode Block */}
                <motion.div 
                  className="relative w-16 metallic-silver rounded-sm shadow-lg cursor-pointer border border-white/20 z-10 overflow-hidden"
                  style={{ height: 220 }} 
                  animate={{ 
                    width: 64 * (anodeMass / ANODE_START_MASS),
                    clipPath: anodeMass < (ANODE_START_MASS * 0.8) ? 'polygon(0% 0%, 100% 0%, 95% 10%, 100% 20%, 90% 30%, 100% 40%, 95% 50%, 100% 60%, 90% 70%, 100% 80%, 95% 90%, 100% 100%, 0% 100%)' : 'none'
                  }} 
                  onClick={spawnIon}
                >
                   <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }}></div>
                   
                   <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                      <span className="text-xs font-bold text-white text-center">Click to<br/>Release</span>
                   </div>
                </motion.div>
                <div className="text-center mt-2 text-sm font-bold text-slate-300">Silver Anode</div>
              </div>

              {/* Cathode (Copper Ring) */}
              <div className="relative flex flex-col items-center" ref={cathodeRef}>
                
                {/* The Electrode Ring */}
                <motion.div 
                  className="relative w-24 h-24 rounded-full border-[20px] shadow-lg z-10 flex items-center justify-center"
                  style={{ 
                    background: 'transparent',
                    marginTop: 40
                  }}
                  animate={{ 
                    borderColor: platedCount > 0 
                      ? `rgb(${Math.round(184 - (platedCount / TOTAL_PLATING_GOAL) * 84)}, ${Math.round(115 - (platedCount / TOTAL_PLATING_GOAL) * 15)}, ${Math.round(51 + (platedCount / TOTAL_PLATING_GOAL) * 200)})`
                      : '#b87333'
                  }}
                >
                   {/* Plated Silver Particles encircling the ring */}
                   {Array.from({ length: TOTAL_PLATING_GOAL }).map((_, i) => {
                       if (i >= platedCount) return null;
                       const angle = (i / TOTAL_PLATING_GOAL) * 360;
                       return (
                           <motion.div
                            key={i}
                            className="absolute w-5 h-5 rounded-full metallic-silver shadow-sm"
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            style={{ 
                                transform: `rotate(${angle}deg) translate(56px) rotate(-${angle}deg)`, // Position radially OUTSIDE ring (radius increased)
                                zIndex: 20
                            }}
                           />
                       )
                   })}

                   {/* WAITING PARTICLES STICKING TO RING (OUTSIDE) */}
                   {ions.filter(p => p.status === 'waiting').map((p, i) => (
                       <motion.div
                         key={p.id}
                         className="absolute w-4 h-4 rounded-full bg-slate-200 border border-slate-400 opacity-80"
                         animate={{ 
                             scale: [1, 1.2, 1],
                             opacity: 0.8
                         }}
                         transition={{ repeat: Infinity, duration: 1.5 }}
                         style={{ 
                             // Distribute waiting ions roughly around the ring (Outside)
                             transform: `rotate(${i * 45}deg) translate(52px) rotate(-${i * 45 + 20}deg)`,
                             zIndex: 25
                         }}
                       />
                   ))}
                   
                   {electrons.filter(p => p.status === 'waiting').map((p, i) => (
                       <motion.div
                         key={p.id}
                         className="absolute w-3 h-3 rounded-full bg-yellow-400 border border-yellow-600 opacity-80"
                         animate={{ 
                             scale: [1, 1.2, 1],
                             opacity: 0.8
                         }}
                         transition={{ repeat: Infinity, duration: 1.5, delay: 0.5 }}
                         style={{ 
                             // Distribute waiting electrons roughly around the ring (offset from ions, Outside)
                             transform: `rotate(${i * 45 + 20}deg) translate(52px) rotate(-${i * 45 + 20}deg)`,
                             zIndex: 25
                         }}
                       />
                   ))}

                   {/* Inner shine effect for ring */}
                   <div className="absolute inset-0 rounded-full border-[2px] border-white/20 pointer-events-none"></div>
                </motion.div>

                <div className="text-center mt-8 text-sm font-bold text-orange-700">Copper Ring</div>
              </div>
            </div>

            {/* Particles Layer */}
            <div className="absolute inset-0 pointer-events-none">
              <AnimatePresence>
                {ions.map((ion) => ion.status === 'active' && (
                  <motion.div
                    key={ion.id}
                    initial={{ x: 90, y: 120, opacity: 0, scale: 0 }} // Start at anode
                    animate={{ 
                      opacity: 1, 
                      scale: 1,
                      y: [120, 130, 110, 120] 
                    }} 
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ 
                      y: { repeat: Infinity, duration: 4, ease: "easeInOut" } 
                    }}
                    drag={true} 
                    dragConstraints={{ left: 0, right: 350, top: 0, bottom: 250 }}
                    dragElastic={0.1}
                    dragMomentum={false}
                    onDragEnd={(e, info) => handleIonDragEnd(ion.id, info)}
                    className="absolute w-10 h-10 rounded-full bg-gradient-to-br from-slate-100 to-slate-300 border border-slate-400 shadow-[0_0_10px_rgba(255,255,255,0.5)] flex items-center justify-center pointer-events-auto cursor-grab active:cursor-grabbing z-50"
                    style={{ touchAction: 'none' }}
                  >
                    <div className="text-xs font-bold text-slate-700 select-none flex flex-col items-center leading-none">
                      <span>Ag</span>
                      <span className="text-[8px] absolute top-1 right-1">+</span>
                    </div>
                  </motion.div>
                ))}

                {electrons.map((electron) => electron.status === 'active' && (
                  <motion.div
                    key={electron.id}
                    initial={{ 
                        x: electron.type === 'anode_electron' ? 0 : 100,
                        y: electron.type === 'anode_electron' ? -120 : -150, 
                        opacity: 0, 
                        scale: 0 
                    }}
                    animate={{ 
                      opacity: 1, 
                      scale: 1,
                    }} 
                    exit={{ scale: 0, opacity: 0 }}
                    drag={true}
                    dragConstraints={
                      electron.type === 'anode_electron' 
                        ? { left: -100, right: 50, top: -250, bottom: 50 } // Constrain to left wire path
                        : { left: -50, right: 100, top: -250, bottom: 150 } // Constrain to right wire path
                    }
                    dragElastic={0.1}
                    dragMomentum={false}
                    onDragEnd={(e, info) => handleElectronDragEnd(electron.id, info, electron.type)}
                    className="absolute w-6 h-6 rounded-full bg-yellow-400 border-2 border-yellow-200 shadow-[0_0_10px_rgba(253,224,71,0.8)] flex items-center justify-center pointer-events-auto cursor-grab active:cursor-grabbing z-50"
                    style={{ touchAction: 'none' }}
                  >
                    <span className="text-[12px] font-bold text-yellow-900 select-none">e⁻</span>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          {/* Legend/Help Text */}
          <div className="absolute bottom-0 right-0 text-xs text-slate-600 italic">
            *Drag particles along grey wires to complete the circuit
          </div>
        </div>

      </main>

        {/* Success Modal */}
        <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
            <DialogContent className="bg-slate-900 border-slate-700 text-slate-100">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-green-400 text-2xl">
                        <Trophy size={24} /> Electroplating Complete!
                    </DialogTitle>
                    <DialogDescription className="text-slate-400 pt-2 text-lg">
                        Copper ring has been successfully electroplated with silver!
                    </DialogDescription>
                </DialogHeader>
                <div className="flex flex-col gap-4 py-4">
                    <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700 text-sm">
                        <p className="mb-2"><strong>Summary:</strong></p>
                        <ul className="list-disc list-inside space-y-1 text-slate-400">
                            <li>Silver Anode mass consumed: {ANODE_START_MASS - anodeMass}g</li>
                            <li>Silver coating applied: {platedCount} units</li>
                            <li>Circuit flow verified</li>
                        </ul>
                    </div>
                    <Button onClick={resetGame} className="w-full bg-primary hover:bg-primary/90 text-white font-bold">
                        Start New Experiment
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    </div>
  );
}